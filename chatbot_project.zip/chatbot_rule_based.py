def chatbot_response(user_input):
    user_input = user_input.lower()
    if "hello" in user_input:
        return "Hi there! How can I help you?"
    elif "bye" in user_input:
        return "Goodbye! Have a nice day!"
    elif "help" in user_input:
        return "Sure! I'm here to assist you."
    else:
        return "I'm not sure how to respond to that."

def run_chatbot():
    print("Chatbot: Type 'exit' to quit.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("Chatbot: Goodbye!")
            break
        print("Chatbot:", chatbot_response(user_input))

if __name__ == "__main__":
    run_chatbot()
